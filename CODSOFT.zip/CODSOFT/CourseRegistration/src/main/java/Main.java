import Control.CourseControl;
import Control.StudentControl;
import Model.StudentModel;
import View.Login;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static Model.StudentModel.getStudent;
import static Model.StudentModel.setStudent;

public class Main {

    private static JFrame frame;
    private static Dimension screenSize;
    private static ExecutorService executorService = Executors.newCachedThreadPool();

    public static void main(String[] args) {
        frame = new JFrame("CODSOFT International University - CIU");
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setSize(screenSize.width,screenSize.height);
        frame.setFocusable(true);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setBackground(Color.WHITE);
        Start();
        new Login(frame);

    }
    public static CompletableFuture<Void> Start() {
        return CompletableFuture.runAsync(() -> {
            new CourseControl().prepareCourses();
            new StudentControl().prepareStudents();

        }, executorService);
    }
}