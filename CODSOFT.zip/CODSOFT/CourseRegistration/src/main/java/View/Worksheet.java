package View;

import Control.RegisterControl;
import Model.CourseModel;
import Model.StudentModel;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

import static Model.StudentModel.getStudent;
import static View.CoursesPanel.*;

public class Worksheet {
    private JPanel mainPanel;
    private ImageIcon imageURL;
    private JLabel image;
    private JLabel worksheet;

    private JPanel panel;
    private JScrollPane scroll;

    private JPanel westPanel;
    private JPanel northPanel;
    private GridBagConstraints gbc;

    private JPanel panel2;
    private JPanel westPanel2;
    private JPanel northPanel2;

    private JLabel Title;
    private JLabel Schedule;
    private JLabel Drop;
    private JButton Return;
    private JButton Confirm;
    private JLabel registeredCredits;
    private JLabel MaxCredits;

    private StudentModel student;

    private static int row=0;

    public Worksheet(JFrame frame, String pass){
        try {
            // Set the Look and Feel to the system's default
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));


        //add the CODSOFT logo
        imageURL = new ImageIcon(Login.class.getResource("/Images/logo.png"));
        image = new JLabel(imageURL);
        image.setHorizontalAlignment(SwingConstants.LEFT);
        image.setVerticalAlignment(SwingConstants.CENTER);
        image.setBorder(BorderFactory.createEmptyBorder(100, 140, 0, 0));
        image.setAlignmentX(Component.LEFT_ALIGNMENT);

        //customising the worksheet label
        worksheet = new JLabel("Worksheet:");
        worksheet.setFont(new Font("Monospace", Font.BOLD, 20));
        worksheet.setHorizontalAlignment(SwingConstants.LEFT);
        worksheet.setVerticalAlignment(SwingConstants.CENTER);
        worksheet.setBorder(BorderFactory.createEmptyBorder(50, 150, 0, 0));
        worksheet.setForeground(Color.DARK_GRAY);
        worksheet.setAlignmentX(Component.LEFT_ALIGNMENT);

        //panel
        panel = MakeWorksheet(frame, panel, pass);

        //west panel
        westPanel = new JPanel();
        westPanel.setLayout(new BorderLayout());
        //get the login panel object => the text fields and labels required
        westPanel.add(panel,BorderLayout.WEST);

        //north panel
        northPanel = new JPanel();
        northPanel.setLayout(new BorderLayout());
        northPanel.add(westPanel,BorderLayout.NORTH);
        northPanel.setBorder(BorderFactory.createEmptyBorder(60,100,0,0));
        northPanel.setAlignmentX(Component.LEFT_ALIGNMENT);


        //add the panel to the scroll
        scroll = new JScrollPane(northPanel);
        scroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);


        for(StudentModel std: getStudent()){
            if(std.getPassword().equals(pass)){
                student=std;
            }
        }

        //this panel to add the registered credits and the max allowed credits and the return button
        panel2 = MakeSubPanel(frame, panel2, student);
        panel2.setAlignmentX(Component.LEFT_ALIGNMENT);

        //west panel2
        westPanel2 = new JPanel();
        westPanel2.setLayout(new BorderLayout());
        //get the login panel object => the text fields and labels required
        westPanel2.add(panel2,BorderLayout.WEST);

        //north panel2
        northPanel2 = new JPanel();
        northPanel2.setLayout(new BorderLayout());
        northPanel2.add(westPanel2,BorderLayout.NORTH);
        northPanel2.setBorder(BorderFactory.createEmptyBorder(60,100,0,0));
        northPanel2.setAlignmentX(Component.LEFT_ALIGNMENT);

        mainPanel.add(image);
        mainPanel.add(worksheet);
        mainPanel.add(northPanel);
        mainPanel.add(northPanel2);


        frame.add(mainPanel);
        frame.repaint();
        frame.revalidate();
        frame.setVisible(true);
    }



    private JPanel MakeWorksheet(JFrame frame, JPanel panel, String pass) {
        panel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 30, 0, 30);
        //customising the Title label
        Title = Column(panel, Title, "Title", 0);
        //customising the Schedule label
        Schedule = Column(panel, Schedule, "Schedule", 1);
        //customising the Drop label
        Drop = Column(panel, Drop, "Drop", 2);

        if (!getCSCset().isEmpty()) {
            for (CourseModel c : getCSCset()) {
                row++;
                JLabel title = Row(panel, c, row, 0);
                JLabel schedule = Row(panel, c, row, 1);
                JButton drop = new JButton("Drop");
                drop.setFocusPainted(false);
                drop.setFocusable(false);
                gbc.gridx = 2;
                gbc.gridy = row;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.NONE;
                gbc.anchor = GridBagConstraints.CENTER;
                panel.add(drop, gbc);

                JPanel finalPanel = panel;
                drop.addActionListener(_ -> {
                    row--;
                    finalPanel.remove(title);
                    finalPanel.remove(schedule);
                    finalPanel.remove(drop);
                    new RegisterControl().Register(pass, c, true);
                    getCSCset().remove(c);
                    frame.remove(mainPanel);
                    frame.repaint();
                    frame.revalidate();
                    new Worksheet(frame,pass);
                });
            }
        }
        if (!getARAset().isEmpty()) {
            for (CourseModel c : getARAset()) {
                row++;
                JLabel title = Row(panel, c, row, 0);
                JLabel schedule = Row(panel, c, row, 1);
                JButton drop = new JButton("Drop");
                drop.setFocusPainted(false);
                drop.setFocusable(false);
                gbc.gridx = 2;
                gbc.gridy = row;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.NONE;
                gbc.anchor = GridBagConstraints.CENTER;
                panel.add(drop, gbc);

                JPanel finalPanel = panel;
                drop.addActionListener(_ -> {
                    row--;
                    finalPanel.remove(title);
                    finalPanel.remove(schedule);
                    finalPanel.remove(drop);
                    new RegisterControl().Register(pass, c, true);
                    getARAset().remove(c);
                    frame.remove(mainPanel);
                    frame.repaint();
                    frame.revalidate();
                    new Worksheet(frame,pass);
                });
            }
        }
        if (!getENGset().isEmpty()) {
            for (CourseModel c : getENGset()) {
                row++;
                JLabel title = Row(panel, c, row, 0);
                JLabel schedule = Row(panel, c, row, 1);
                JButton drop = new JButton("Drop");
                drop.setFocusPainted(false);
                drop.setFocusable(false);
                gbc.gridx = 2;
                gbc.gridy = row;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.NONE;
                gbc.anchor = GridBagConstraints.CENTER;
                panel.add(drop, gbc);

                JPanel finalPanel = panel;
                drop.addActionListener(_ -> {
                    row--;
                    finalPanel.remove(title);
                    finalPanel.remove(schedule);
                    finalPanel.remove(drop);
                    new RegisterControl().Register(pass, c, true);
                    getENGset().remove(c);
                    frame.remove(mainPanel);
                    frame.repaint();
                    frame.revalidate();
                    new Worksheet(frame,pass);
                });
            }
        }
        if (!getMTHset().isEmpty()) {
            for (CourseModel c : getMTHset()) {
                row++;
                JLabel title = Row(panel, c, row, 0);
                JLabel schedule = Row(panel, c, row, 1);
                JButton drop = new JButton("Drop");
                drop.setFocusPainted(false);
                drop.setFocusable(false);
                gbc.gridx = 2;
                gbc.gridy = row;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.NONE;
                gbc.anchor = GridBagConstraints.CENTER;
                panel.add(drop, gbc);

                JPanel finalPanel = panel;
                drop.addActionListener(_ -> {
                    row--;
                    finalPanel.remove(title);
                    finalPanel.remove(schedule);
                    finalPanel.remove(drop);
                    new RegisterControl().Register(pass, c, true);
                    getMTHset().remove(c);
                    frame.remove(mainPanel);
                    frame.repaint();
                    frame.revalidate();
                    new Worksheet(frame,pass);
                });
            }
        }
        if (!getLACset().isEmpty()) {
            for (CourseModel c : getLACset()) {
                row++;
                JLabel title = Row(panel, c, row, 0);
                JLabel schedule = Row(panel, c, row, 1);
                JButton drop = new JButton("Drop");
                drop.setFocusPainted(false);
                drop.setFocusable(false);
                gbc.gridx = 2;
                gbc.gridy = row;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.NONE;
                gbc.anchor = GridBagConstraints.CENTER;
                panel.add(drop, gbc);

                JPanel finalPanel = panel;
                drop.addActionListener(_ -> {
                    row--;
                    finalPanel.remove(title);
                    finalPanel.remove(schedule);
                    finalPanel.remove(drop);
                    new RegisterControl().Register(pass, c, true);
                    getLACset().remove(c);
                    frame.remove(mainPanel);
                    frame.repaint();
                    frame.revalidate();
                    new Worksheet(frame,pass);
                });
            }
        }

        return panel;
    }


    private JLabel Column(JPanel panel, JLabel columnLabel, String text, int column) {
        columnLabel = new JLabel(text);
        columnLabel.setFont(new Font("Arial", Font.BOLD, 16));
        columnLabel.setHorizontalAlignment(SwingConstants.LEFT);
        columnLabel.setVerticalAlignment(SwingConstants.CENTER);
        columnLabel.setBorder(BorderFactory.createEmptyBorder(8, 10, 0, 10));

        gbc.gridx = column;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(columnLabel);

        return columnLabel;
    }
    private JLabel Row(JPanel panel, CourseModel c, int row, int column) {
        JLabel rowLabel = null;
        if(column==0){
            rowLabel = new JLabel(String.valueOf(c.getTitle()));
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(rowLabel, gbc);
        }
        else if(column==1){
            rowLabel = new JLabel(String.valueOf(c.getSchedule()));
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(rowLabel, gbc);
        }
        return rowLabel;

    }

    private JPanel MakeSubPanel(JFrame frame, JPanel Panel2, StudentModel student) {
        Panel2 = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 30, 0, 30);

        registeredCredits = new JLabel("Registered Credits: "+student.getRegistered_Credits());
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0,15,25,0);
        Panel2.add(registeredCredits, gbc);

        MaxCredits = new JLabel("Max. Allowed Credits: "+student.getCREDITS());
        MaxCredits.setForeground(new Color(200,0,0));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0,15,25,0);
        Panel2.add(MaxCredits, gbc);

        //confirm the registration and make a schedule
        Confirm = new JButton("Confirm and make Schedule");
        Confirm.setFocusable(false);
        Confirm.setFocusPainted(false);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        Panel2.add(Confirm, gbc);

        Confirm.addActionListener(_ -> {
            ArrayList<CourseModel> list = new ArrayList<>();
            list.addAll(getCSCset());
            list.addAll(getARAset());
            list.addAll(getENGset());
            list.addAll(getLACset());
            list.addAll(getMTHset());
            new RegisterControl().RegisterCourses(student,list);
            frame.remove(mainPanel);
            new Schedule(frame, student);
        });
        //back to choose course
        Return = new JButton("Return");
        Return.setFocusable(false);
        Return.setFocusPainted(false);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        Panel2.add(Return, gbc);

        Return.addActionListener(_ -> {
            frame.remove(mainPanel);
            new ChooseCourse(frame);
        });
        return Panel2;
    }
}
