package View;

import Model.CourseModel;
import Model.StudentModel;

import javax.swing.*;
import java.awt.*;

public class Schedule {
    private JPanel mainPanel;
    private GridBagConstraints gbc;

    private JLabel Course;
    private JLabel Title;
    private JLabel Location;
    private JLabel Instructor;
    private JLabel Grade;

    private JLabel course;
    private JLabel title;
    private JLabel location;
    private JLabel instructor;
    private JLabel grade;
    private static int row = 0;

    private JButton Return;
    public Schedule(JFrame frame, StudentModel student) {
        try {
            // Set the Look and Feel to the system's default
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        mainPanel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 30, 0, 30);

        //customising the Course label
        Course = Column(mainPanel, Course, "Course",0);

        //customising the Title label
        Title = Column(mainPanel, Title, "Title",1);

        //customising the Instructor label
        Instructor = Column(mainPanel, Instructor, "Instructor",2);

        //customising the Location label
        Location = Column(mainPanel, Location, "Location",3);

        //customising the Grade label
        Grade = Column(mainPanel, Grade, "Grade",4);

        for(CourseModel c : student.getRegisteredCourses()){
            row++;
            course = Row(mainPanel, course, c, row,0);
            title = Row(mainPanel, title, c, row,1);
            instructor = Row(mainPanel, instructor, c, row,2);
            location = Row(mainPanel, location, c, row,3);
            grade = Row(mainPanel, grade, c, row,4);

        }
        //back to choose course
        row++;
        Return = new JButton("Return");
        Return.setFocusable(false);
        Return.setFocusPainted(false);
        gbc.gridx = 4;
        gbc.gridy = row;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20,0,0,0);
        Return.addActionListener(_ -> {
            frame.remove(mainPanel);
            new Worksheet(frame,student.getPassword());
        });
        mainPanel.add(Return, gbc);

        frame.add(mainPanel);
        frame.repaint();
        frame.revalidate();
        frame.setVisible(true);
    }


    private JLabel Column(JPanel mainPanel, JLabel columnLabel, String text, int column) {
        columnLabel = new JLabel(text);
        columnLabel.setForeground(new Color(0,100,0));
        columnLabel.setFont(new Font("Arial", Font.BOLD, 16));
        columnLabel.setHorizontalAlignment(SwingConstants.LEFT);
        columnLabel.setVerticalAlignment(SwingConstants.CENTER);
        columnLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));

        gbc.gridx = column;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(columnLabel);

        return columnLabel;
    }

    private JLabel Row(JPanel mainPanel, JLabel rowLabel, CourseModel c, int row, int column) {
        if(column==0){
            rowLabel = new JLabel(c.getCourse());
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;


            mainPanel.add(rowLabel, gbc);
        }
        else if(column==1){
            String text = "<html>"+c.getTitle()+"<br>"+c.getSchedule()+"</html>";
            rowLabel = new JLabel(text);
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            mainPanel.add(rowLabel, gbc);
        }
        else if(column==2){
            rowLabel = new JLabel(c.getInstructor());
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            mainPanel.add(rowLabel, gbc);
        }
        else if(column==3){
            String text = "<html>"+c.getLocation()+"/"+"<br>"+c.getSection()+"</html>";
            rowLabel = new JLabel(text);
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            mainPanel.add(rowLabel, gbc);
        }
        else if(column==4){
            rowLabel = new JLabel("");
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            mainPanel.add(rowLabel, gbc);
        }
        return rowLabel;
    }

}
