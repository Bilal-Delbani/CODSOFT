package View;
import Control.CheckConflictsControl;
import Control.RegisterControl;
import Model.CourseModel;
import javax.swing.*;
import java.awt.*;
import java.util.HashSet;

import static Model.CourseModel.*;


public class CoursesPanel {
    private GridBagConstraints gbc;

    //labels for the columns;
    private JLabel Blank;
    private JLabel Course;
    private JLabel Title;
    private JLabel Capacity;
    private JLabel Remained_Slots;
    private JLabel Schedule;
    private JLabel Location;
    private JLabel Section;
    private JLabel Instructor;

    //labels for the rows where the courses are actually shown
    private JLabel course;
    private JLabel title;
    private JLabel capacity;
    private JLabel remained;
    private JLabel schedule;
    private JLabel location;
    private JLabel section;
    private JLabel instructor;

    private ButtonGroup group = new ButtonGroup();

    private static HashSet<CourseModel> CSC = new HashSet<>();
    private static HashSet<CourseModel> ARA = new HashSet<>();
    private static HashSet<CourseModel> MTH = new HashSet<>();
    private static HashSet<CourseModel> ENG = new HashSet<>();
    private static HashSet<CourseModel> LAC = new HashSet<>();

    JPanel MakePanel(JPanel panel, String option, String pass) {
        panel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 30, 0, 30); // Add padding around components

        Blank = Column(panel, Blank, "",0);

        //customising the Course label
        Course = Column(panel, Course, "Course",1);

        //customising the Title label
        Title = Column(panel, Title, "Title",2);

        //customising the Capacity label
        Capacity = Column(panel, Capacity, "Capacity",3);

        //customising the Remained slots label
        Remained_Slots = Column(panel, Remained_Slots, "Remained Slots",4);

        //customising the Schedule label
        Schedule = Column(panel, Schedule, "Schedule",5);

        //customising the Location label
        Location = Column(panel, Location, "Location",6);

        //customising the Section label
        Section = Column(panel, Section, "Section",7);

        //customising the Instructor label
        Instructor = Column(panel, Instructor, "Instructor",8);

        int row=0;
        if (option.equals("Arabic Courses")){
            for(CourseModel c : getARA()){
                row++;
                course = Row(panel, course, c, row,1, ARA, pass);
                title = Row(panel, title, c, row,2, ARA, pass);
                capacity = Row(panel, capacity, c, row,3, ARA, pass);
                remained = Row(panel, remained, c, row,4, ARA, pass);
                schedule = Row(panel, schedule, c, row,5, ARA, pass);
                location = Row(panel, location, c, row,6, ARA, pass);
                section = Row(panel, section, c, row,7, ARA, pass);
                instructor = Row(panel, instructor, c, row,8, ARA, pass);
            }
        } else if (option.equals("Computer Science Courses")) {
            for(CourseModel c : getCSC()){
                row++;
                course = Row(panel, course, c, row,1, CSC, pass);
                title = Row(panel, title, c, row,2, CSC, pass);
                capacity = Row(panel, capacity, c, row,3, CSC, pass);
                remained = Row(panel, remained, c, row,4, CSC, pass);
                schedule = Row(panel, schedule, c, row,5, CSC, pass);
                location = Row(panel, location, c, row,6, CSC, pass);
                section = Row(panel, section, c, row,7, CSC, pass);
                instructor = Row(panel, instructor, c, row,8, CSC, pass);
            }

        } else if (option.equals("English Courses")) {
            for(CourseModel c : getENG()){
                row++;
                course = Row(panel, course, c, row,1, ENG, pass);
                title = Row(panel, title, c, row,2, ENG, pass);
                capacity = Row(panel, capacity, c, row,3, ENG, pass);
                remained = Row(panel, remained, c, row,4, ENG, pass);
                schedule = Row(panel, schedule, c, row,5, ENG, pass);
                location = Row(panel, location, c, row,6, ENG, pass);
                section = Row(panel, section, c, row,7, ENG, pass);
                instructor = Row(panel, instructor, c, row,8, ENG, pass);
            }
        } else if (option.equals("LAC Courses")) {
            for(CourseModel c : getLAC()){
                row++;
                course = Row(panel, course, c, row,1, LAC, pass);
                title = Row(panel, title, c, row,2, LAC, pass);
                capacity = Row(panel, capacity, c, row,3, LAC, pass);
                remained = Row(panel, remained, c, row,4, LAC, pass);
                schedule = Row(panel, schedule, c, row,5, LAC, pass);
                location = Row(panel, location, c, row,6, LAC, pass);
                section = Row(panel, section, c, row,7, LAC, pass);
                instructor = Row(panel, instructor, c, row,8, LAC, pass);
            }
        } else if (option.equals("Mathematics Courses")) {
            for(CourseModel c : getMTH()){
                row++;
                course = Row(panel, course, c, row,1, MTH, pass);
                title = Row(panel, title, c, row,2, MTH, pass);
                capacity = Row(panel, capacity, c, row,3, MTH, pass);
                remained = Row(panel, remained, c, row,4, MTH, pass);
                schedule = Row(panel, schedule, c, row,5, MTH, pass);
                location = Row(panel, location, c, row,6, MTH, pass);
                section = Row(panel, section, c, row,7, MTH, pass);
                instructor = Row(panel, instructor, c, row,8, MTH, pass);
            }
        }
        return panel;
    }


    private JLabel Column(JPanel panel, JLabel columnLabel, String text, int column) {
        columnLabel = new JLabel(text);
        columnLabel.setForeground(new Color(0,100,0));
        columnLabel.setFont(new Font("Arial", Font.BOLD, 16));
        columnLabel.setHorizontalAlignment(SwingConstants.LEFT);
        columnLabel.setVerticalAlignment(SwingConstants.CENTER);
        columnLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));

        gbc.gridx = column;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(columnLabel);

        return columnLabel;
    }

    private JLabel Row(JPanel panel, JLabel rowLabel, CourseModel c, int row, int column, HashSet<CourseModel> set, String pass) {
        if(column==1){
            if(c.getRemained_Slots()>0 && c.getRemained_Slots()<=40){
                if(c.getCourse().substring(0,3).equals("ENG") || c.getCourse().substring(0,3).equals("CSC") || c.getCourse().substring(0,3).equals("ARA") || c.getCourse().substring(0,3).equals("MTH")){
                    JRadioButton radio = new JRadioButton();
                    group.add(radio);
                    gbc.gridx = 0;
                    gbc.gridy = row;
                    gbc.gridwidth = 1;
                    gbc.anchor = GridBagConstraints.WEST;

                    radio.addActionListener(_ -> {
                        if (radio.isSelected()) {
                            boolean add = true;
                            if(!set.isEmpty()){
                                JOptionPane.showMessageDialog(null, "<html>Registration Conflict!!<br>A Course of same title was already selected...<br>You can drop the previous one from the worksheet.</html>");
                                add = false;
                            }
                            if(!new CheckConflictsControl().CheckCredits(c, pass)){
                                JOptionPane.showMessageDialog(null, "<html>Registration Conflict!!<br>You are trying to exceed the allowed number of credits to register per semester<br>If you need this course, you can drop one course from the worksheet.</html>");
                                add = false;
                            }
                            if(!new CheckConflictsControl().CheckTime(c)){
                                JOptionPane.showMessageDialog(null, "<html>Time Conflict!!<br>A Course of same schedule was already selected...<br>You can choose another section or drop one of the previous courses from the worksheet.</html>");
                                add = false;
                            }

                            if(add){
                                set.add(c);
                                new RegisterControl().Register(pass, c, false);
                            }


                        }
                    });

                    panel.add(radio, gbc);

                }
                else{
                    JCheckBox check = new JCheckBox();
                    gbc.gridx = 0;
                    gbc.gridy = row;
                    gbc.gridwidth = 1;
                    gbc.anchor = GridBagConstraints.WEST;

                    check.addActionListener(_ -> {
                        if (check.isSelected()) {
                            boolean add = true;
                            if(!new CheckConflictsControl().CheckCredits(c, pass)){
                                JOptionPane.showMessageDialog(null, "<html>Registration Conflict!!<br>You are trying to exceed the allowed number of credits to register per semester<br>If you need this course, you can drop one course from the worksheet.</html>");
                                add = false;
                            }
                            if(!new CheckConflictsControl().CheckTime(c)){
                                JOptionPane.showMessageDialog(null, "<html>Time Conflict!!<br>A Course of same schedule was already selected...<br>You can choose another section or drop one of the previous courses from the worksheet.</html>");
                                add = false;
                            }
                            if(add){
                                set.add(c);
                                new RegisterControl().Register(pass, c, false);
                            }
                        }
                    });

                    panel.add(check, gbc);
                }

            }
            else{
                JLabel closed = new JLabel("  C");
                closed.setFont(new Font("Arial", Font.BOLD, 12));
                closed.setForeground(new Color(111,111,111));
                gbc.gridx = 0;
                gbc.gridy = row;
                gbc.gridwidth = 1;
                gbc.anchor = GridBagConstraints.WEST;
                panel.add(closed, gbc);
            }
        }

        if(column==1){
            rowLabel = new JLabel("<html><a href= ''>"+c.getCourse()+"</a></html>");
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setForeground(new Color(0,120,140));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            rowLabel.setToolTipText(c.getDescription());
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;


            panel.add(rowLabel, gbc);
        }
        else if(column==2){
            rowLabel = new JLabel(c.getTitle());
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(rowLabel, gbc);
        }
        else if(column==3){
            rowLabel = new JLabel(String.valueOf(c.getCapacity()));
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(rowLabel, gbc);
        }
        else if(column==4){
            rowLabel = new JLabel(String.valueOf(c.getRemained_Slots()));
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(rowLabel, gbc);
        }
        else if(column==5){
            rowLabel = new JLabel(c.getSchedule());
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(rowLabel, gbc);
        }
        else if(column==6){
            rowLabel = new JLabel(c.getLocation());
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(rowLabel, gbc);
        }
        else if(column==7){
            rowLabel = new JLabel(String.valueOf(c.getSection()));
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(rowLabel, gbc);
        }
        else if(column==8){
            rowLabel = new JLabel(c.getInstructor());
            rowLabel.setFont(new Font("Monospace", Font.PLAIN, 12));
            rowLabel.setHorizontalAlignment(SwingConstants.LEFT);
            rowLabel.setVerticalAlignment(SwingConstants.CENTER);
            rowLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            //adding the label
            gbc.gridx = column;
            gbc.gridy = row;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(rowLabel, gbc);
        }

        return rowLabel;
    }
    public static HashSet<CourseModel> getCSCset() {
        return CSC;
    }

    public static HashSet<CourseModel> getARAset() {
        return ARA;
    }

    public static HashSet<CourseModel> getMTHset() {
        return MTH;
    }

    public static HashSet<CourseModel> getENGset() {
        return ENG;
    }

    public static HashSet<CourseModel> getLACset() {
        return LAC;
    }
}
