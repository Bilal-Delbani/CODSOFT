package View;
import Customising.CustomButton;
import Model.StudentModel;
import javax.swing.*;
import java.awt.*;
import java.util.HashSet;
import static Model.StudentModel.getStudent;


public class ChooseCourse {
    //this panel will include all the components in the frame : main panel
    private JPanel mainPanel;
    //this panel will have the spinner panel, and it will be used to move it to the west
    private JPanel westPanel;
    //this panel is used to move the west panel to the north
    private JPanel northPanel;
    private JPanel spinnerPanel;

    private ImageIcon imageURL;
    private JLabel image;
    private JLabel choose;
    private JLabel note;

    private JButton Register;
    private JComboBox<String> spinner;
    private final String[] courses = {"","Arabic Courses", "Computer Science Courses", "English Courses", "LAC Courses", "Mathematics Courses"};

    private GridBagConstraints gbc;

    private HashSet<StudentModel> set = getStudent();

    private String option;

    private static String pass;

    public ChooseCourse(JFrame frame){
        try {
            // Set the Look and Feel to the system's default
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }


        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        String name = "";
        for(StudentModel s : set){
            if(s.getPassword().equals(pass)){
                name = s.getFullName();
            }
        }
        //customising the note label
        note = new JLabel("Welcome "+name+"                                                                                                                                                                                                                                                                                                                                              ");
        note.setFont(new Font("Aptos", Font.PLAIN, 17));
        note.setHorizontalAlignment(SwingConstants.LEFT);
        note.setVerticalAlignment(SwingConstants.CENTER);
        note.setBorder(BorderFactory.createEmptyBorder(30, 150, 0, 0));
        note.setForeground(new Color(88,88,88));
        note.setAlignmentX(Component.LEFT_ALIGNMENT);

        //add the CODSOFT logo
        imageURL = new ImageIcon(Login.class.getResource("/Images/logo.png"));
        image = new JLabel(imageURL);
        image.setHorizontalAlignment(SwingConstants.LEFT);
        image.setVerticalAlignment(SwingConstants.CENTER);
        image.setBorder(BorderFactory.createEmptyBorder(70, 140, 0, 0));
        image.setAlignmentX(Component.LEFT_ALIGNMENT);

        //customising the choose label
        choose = new JLabel("Register your courses:");
        choose.setFont(new Font("Monospace", Font.BOLD, 20));
        choose.setHorizontalAlignment(SwingConstants.LEFT);
        choose.setVerticalAlignment(SwingConstants.CENTER);
        choose.setBorder(BorderFactory.createEmptyBorder(50, 150, 0, 0));
        choose.setForeground(Color.DARK_GRAY);
        choose.setAlignmentX(Component.LEFT_ALIGNMENT);


        spinnerPanel = makeSpinner(frame, spinnerPanel, pass);

        //west panel
        westPanel = new JPanel();
        westPanel.setLayout(new BorderLayout());
        //get the spinner panel
        westPanel.add(spinnerPanel,BorderLayout.WEST);

        //north panel
        northPanel = new JPanel();
        northPanel.setLayout(new BorderLayout());
        northPanel.add(westPanel,BorderLayout.NORTH);
        northPanel.setBorder(BorderFactory.createEmptyBorder(60,150,0,0));
        northPanel.setAlignmentX(Component.LEFT_ALIGNMENT);


        mainPanel.add(note);
        mainPanel.add(image);
        mainPanel.add(choose);
        mainPanel.add(northPanel);

        frame.add(mainPanel);
        frame.repaint();
        frame.revalidate();
        frame.setVisible(true);

    }

    private JPanel makeSpinner(JFrame frame, JPanel spinnerPanel, String pass) {
        spinnerPanel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 5, 20, 5); // Add padding around components

        //spinner for grouping courses based on their field
        spinner = new JComboBox<>(courses);
        //spinner.setBounds(200, 50,90,20);
        spinner.setFocusable(false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.ipady = 10;
        gbc.ipadx = 25;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        spinnerPanel.add(spinner, gbc);

        //creating and adding the Register button
        Register = new CustomButton("Register",Color.WHITE, new Color(220,220,220));
        Register.setFont(new Font("Aptos", Font.BOLD, 14));
        Register.setEnabled(false);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.ipady = 8;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(17,8,35,150);
        spinnerPanel.add(Register, gbc);

        spinner.addActionListener(_ -> {
            option = (String) spinner.getSelectedItem();
            if(option.equals("")){
                Register.setEnabled(false);
            }
            else {
                Register.setEnabled(true);
            }
        });

        Register.addActionListener(_ -> {
            frame.remove(mainPanel);
            new ShowCourses(frame, option, pass);
        });

        return spinnerPanel;
    }

    public static void setPass(String pass) {
        ChooseCourse.pass = pass;
    }

}
