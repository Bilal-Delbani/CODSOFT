package View;

import Control.ForgetPassControl;
import Control.StudentControl;
import Customising.CustomButton;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.CompletableFuture;

import static View.LoginPanel.CustomiseLabel;

public class ForgetPass {
    private static JPanel mainPanel;
    private static JPanel Panel;
    private static GridBagConstraints gbc;
    private static ImageIcon imageURL;
    private static JLabel image;
    private static JLabel Recovery;
    private static JLabel ConfirmationID;
    private static JTextField confirmID;
    private static JLabel NewPassword;
    private static JPasswordField newPass;
    private static JLabel ConfirmPass;
    private static JPasswordField confirmPass;
    private static JButton Verify;
    private static JButton Cancel;

    private static JPanel northPanel;
    private static JPanel westPanel;
    private static JLabel note;


    public ForgetPass(JFrame frame){
        try {
            // Set the Look and Feel to the system's default
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        //mainPanel
        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        //panel for Email
        Panel = makePanel(frame);

        //add the CODSOFT logo
        imageURL = new ImageIcon(Login.class.getResource("/Images/logo.png"));
        image = new JLabel(imageURL);
        image.setHorizontalAlignment(SwingConstants.LEFT);
        image.setVerticalAlignment(SwingConstants.CENTER);
        image.setBorder(BorderFactory.createEmptyBorder(100, 140, 0, 0));
        image.setAlignmentX(Component.LEFT_ALIGNMENT);

        //customising the Password Recovery Method label
        Recovery = new JLabel("Password Recovery Method                                                                                                                            ");
        Recovery.setFont(new Font("Monospace", Font.BOLD, 27));
        Recovery.setHorizontalAlignment(SwingConstants.LEFT);
        Recovery.setVerticalAlignment(SwingConstants.CENTER);
        Recovery.setBorder(BorderFactory.createEmptyBorder(50, 150, 0, 0));
        Recovery.setForeground(Color.DARK_GRAY);
        Recovery.setAlignmentX(Component.LEFT_ALIGNMENT);

        //customising the note label
        note = new JLabel("ConfirmationID is your first name with your ID in the form: Fname#########.                                                                                                                                                                           ");
        note.setFont(new Font("Aptos", Font.PLAIN, 18));
        note.setHorizontalAlignment(SwingConstants.LEFT);
        note.setVerticalAlignment(SwingConstants.CENTER);
        note.setBorder(BorderFactory.createEmptyBorder(50, 150, 0, 0));
        note.setForeground(new Color(88,88,88));
        note.setAlignmentX(Component.LEFT_ALIGNMENT);

        //west panel
        westPanel = new JPanel();
        westPanel.setLayout(new BorderLayout());
        westPanel.add(Panel,BorderLayout.WEST);

        //north panel
        northPanel = new JPanel();
        northPanel.setLayout(new BorderLayout());
        northPanel.add(westPanel,BorderLayout.NORTH);
        northPanel.setBorder(BorderFactory.createEmptyBorder(110,150,0,0));
        northPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        mainPanel.add(image);
        mainPanel.add(Recovery);
        mainPanel.add(note);
        mainPanel.add(northPanel);

        //set up the frame
        frame.add(mainPanel,BorderLayout.WEST);
        frame.repaint();
        frame.revalidate();
        frame.setVisible(true);

    }

    private JPanel makePanel(JFrame frame) {
        Panel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 5, 20, 5); // Add padding around components

        //customising the ConfirmationID label
        ConfirmationID = CustomiseLabel(ConfirmationID,"Confirmation ID       ");
        //adding the Email label
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        Panel.add(ConfirmationID, gbc);

        //creating and adding the confirmID text field
        confirmID = new JPasswordField(25);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.ipady = 10;
        gbc.ipadx = 15;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        Panel.add(confirmID, gbc);

        //creating and adding the Verify button
        Verify = new CustomButton("Verify",Color.WHITE, new Color(220,220,220));
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.ipady = 17;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10,10,0,150);
        Panel.add(Verify, gbc);

        //creating and adding the Cancel button
        Cancel = new CustomButton("Cancel",Color.WHITE, new Color(220,220,220));
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.ipady = 17;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0,15,25,0);
        Panel.add(Cancel, gbc);

        Cancel.addActionListener(_ -> {
            frame.remove(mainPanel);
            new Login(frame);
        });


        //Verify
        Verify.addActionListener(_ -> {

            // Call the authenticate method asynchronously
            CompletableFuture<Boolean> future = new ForgetPassControl().Verify(confirmID);
            future.thenAccept(isAuthenticated -> {
                SwingUtilities.invokeLater(() -> {
                    if (isAuthenticated) {
                        forgetPass(frame);
                    } else {
                        JOptionPane.showMessageDialog(null, "Incorrect Confirmation ID...");
                        frame.remove(mainPanel);
                        new Login(frame);                        }
                });
            }).exceptionally(ex -> {
                // Handle exceptions and update the UI on the Event Dispatch Thread
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                });
                return null;
            });
        });

        return Panel;
    }

    public static void forgetPass(JFrame frame){
        mainPanel.remove(note);
        Panel.remove(ConfirmationID);
        Panel.remove(confirmID);
        Panel.remove(Verify);
        Panel.remove(Cancel);

        //customising the NewPassword label
        NewPassword = CustomiseLabel(NewPassword,"New Password       ");
        //adding the NewPassword label
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        Panel.add(NewPassword, gbc);

        //creating and adding the newPass text field
        newPass = new JPasswordField(25);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.ipady = 10;
        gbc.ipadx = 15;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        Panel.add(newPass, gbc);

        //customising the ConfirmPass label
        ConfirmPass = CustomiseLabel(ConfirmPass,"Confirm Password       ");
        //adding the NewPassword label
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        Panel.add(ConfirmPass, gbc);

        //creating and adding the confirmPass text field
        confirmPass = new JPasswordField(25);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.ipady = 10;
        gbc.ipadx = 15;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        Panel.add(confirmPass, gbc);

        //creating and adding the Cancel button
        Cancel = new CustomButton("Cancel",Color.WHITE, new Color(220,220,220));
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.ipady = 17;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0,15,25,0);
        Panel.add(Cancel, gbc);

        Cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.remove(mainPanel);
                new Login(frame);
            }
        });


        //creating and adding the Verify button
        //for making it to submit the new Password
        Verify = new CustomButton("Submit",Color.WHITE, new Color(220,220,220));
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.ipady = 17;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10,10,0,150);
        Panel.add(Verify, gbc);


        //Verify
        Verify.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // Call the authenticate method asynchronously
                //check if the password and confirm password are equal
                boolean check = new ForgetPassControl().Check(newPass,confirmPass);
                // if they are not equal
                if(check==false){
                    JOptionPane.showMessageDialog(null, "Empty Password or the Password and Confirm Password are not equal.");
                    newPass.setText("");
                    confirmPass.setText("");
                }
                // if they are equal then change the password
                else{
                    CompletableFuture<Boolean> future = new ForgetPassControl().Change(newPass);
                    future.thenAccept(isAuthenticated -> {
                        SwingUtilities.invokeLater(() -> {
                            // if changing is done successfully
                            if (isAuthenticated) {
                                JOptionPane.showMessageDialog(null, "Password has been changed...");
                                frame.remove(mainPanel);
                                new Login(frame);
                            } else {
                                JOptionPane.showMessageDialog(null, "Error!!!");
                                frame.remove(mainPanel);
                                new ForgetPass(frame);
                            }
                        });
                    }).exceptionally(ex -> {
                        // Handle exceptions and update the UI on the Event Dispatch Thread
                        SwingUtilities.invokeLater(() -> {
                            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                        });
                        return null;
                    });
                }
            }
        });

        frame.revalidate();
        frame.repaint();
    }

}
