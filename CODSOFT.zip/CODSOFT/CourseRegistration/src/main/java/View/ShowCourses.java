package View;
import javax.swing.*;
import java.awt.*;


public class ShowCourses {
    private JPanel mainPanel;
    private ImageIcon imageURL;
    private JLabel image;
    private JLabel choose;

    private JPanel panel;
    private JScrollPane scroll;

    private JPanel westPanel;
    private JPanel northPanel;

    private JPanel panel2;
    private JPanel westPanel2;
    private JPanel northPanel2;
    private GridBagConstraints gbc;


    private JButton Return;
    private JButton Add_to_Worksheet;


    public ShowCourses(JFrame frame, String option, String pass) {
        try {
            // Set the Look and Feel to the system's default
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));


        //add the CODSOFT logo
        imageURL = new ImageIcon(Login.class.getResource("/Images/logo.png"));
        image = new JLabel(imageURL);
        image.setHorizontalAlignment(SwingConstants.LEFT);
        image.setVerticalAlignment(SwingConstants.CENTER);
        image.setBorder(BorderFactory.createEmptyBorder(100, 140, 0, 0));
        image.setAlignmentX(Component.LEFT_ALIGNMENT);

        //customising the choose label
        choose = new JLabel("<html>Register your courses:  <small>Each course is 3 credits</small></html>");
        choose.setFont(new Font("Monospace", Font.BOLD, 20));
        choose.setHorizontalAlignment(SwingConstants.LEFT);
        choose.setVerticalAlignment(SwingConstants.CENTER);
        choose.setBorder(BorderFactory.createEmptyBorder(50, 150, 0, 0));
        choose.setForeground(Color.DARK_GRAY);
        choose.setAlignmentX(Component.LEFT_ALIGNMENT);

        //panel
        panel = new CoursesPanel().MakePanel(panel, option, pass);
        //west panel
        westPanel = new JPanel();
        westPanel.setLayout(new BorderLayout());
        //get the login panel object => the text fields and labels required
        westPanel.add(panel,BorderLayout.WEST);

        //north panel
        northPanel = new JPanel();
        northPanel.setLayout(new BorderLayout());
        northPanel.add(westPanel,BorderLayout.NORTH);
        northPanel.setBorder(BorderFactory.createEmptyBorder(60,100,0,0));
        northPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        //add the panel to the scroll
        scroll = new JScrollPane(northPanel);
        scroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        scroll.setPreferredSize(new Dimension(130,10));

        //this panel will add the return button and the add to worksheet button
        panel2 = MakeSubPanel(frame, panel2, pass);
        panel2.setAlignmentX(Component.LEFT_ALIGNMENT);

        //west panel2
        westPanel2 = new JPanel();
        westPanel2.setLayout(new BorderLayout());
        //get the login panel object => the text fields and labels required
        westPanel2.add(panel2,BorderLayout.WEST);

        //north panel2
        northPanel2 = new JPanel();
        northPanel2.setLayout(new BorderLayout());
        northPanel2.add(westPanel2,BorderLayout.NORTH);
        northPanel2.setBorder(BorderFactory.createEmptyBorder(60,100,0,0));
        northPanel2.setAlignmentX(Component.LEFT_ALIGNMENT);


        mainPanel.add(image);
        mainPanel.add(choose);
        mainPanel.add(northPanel);
        mainPanel.add(northPanel2);


        frame.add(mainPanel);
        frame.repaint();
        frame.revalidate();
        frame.setVisible(true);
    }

    private JPanel MakeSubPanel(JFrame frame, JPanel Panel2, String pass) {
        Panel2 = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 20, 0, 0);

        Add_to_Worksheet = new JButton("Add to Worksheet");
        Add_to_Worksheet.setFocusable(false);
        Add_to_Worksheet.setFocusPainted(false);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        Add_to_Worksheet.addActionListener(_ -> {
            frame.remove(mainPanel);
            new Worksheet(frame,pass);
        });
        Panel2.add(Add_to_Worksheet, gbc);


        //back to choose course
        Return = new JButton("Return");
        Return.setFocusable(false);
        Return.setFocusPainted(false);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;

        Return.addActionListener(_ -> {
            frame.remove(mainPanel);
            new ChooseCourse(frame);
        });
        Panel2.add(Return, gbc);

        return Panel2;
    }

}
