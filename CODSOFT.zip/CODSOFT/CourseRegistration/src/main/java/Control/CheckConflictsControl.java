package Control;

import Model.CourseModel;
import Services.CheckConflictsService;

public class CheckConflictsControl {
    private CheckConflictsService conflictsService = new CheckConflictsService();
    public boolean CheckTime(CourseModel c) {
        return conflictsService.CheckTime(c);
    }

    public boolean CheckCredits(CourseModel c, String pass) {
        return conflictsService.CheckCredits(c,pass);
    }
}
