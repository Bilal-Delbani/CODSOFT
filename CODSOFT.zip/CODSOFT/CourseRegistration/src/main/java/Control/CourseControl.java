package Control;

import Repositories.CourseRepository;

public class CourseControl {
    private CourseRepository prepare = new CourseRepository();
    public CourseControl(){}
    public void prepareCourses(){
        prepare.Prepare();
    }
}
