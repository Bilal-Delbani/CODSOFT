package Control;

import Services.LoginService;

import javax.swing.*;
import java.util.concurrent.CompletableFuture;

public class LoginControl {
    private LoginService login = new LoginService();
    private String username;
    private String password;

    public boolean Login(JTextField Username , JPasswordField Password){
        setUsername(Username);
        setPassword(Password);
        return login.Authenticate(username,password);

    }
    public void setUsername(JTextField Username){
        username = Username.getText();
    }
    public void setPassword(JPasswordField Password){
        password = new String(Password.getPassword());
    }

    public String getStudentName() {
        return login.getFullName();
    }
}
