package Control;

import Services.ForgetPassService;

import javax.swing.*;
import java.util.concurrent.CompletableFuture;

public class ForgetPassControl {
    private ForgetPassService send = new ForgetPassService();
    private String confirmID;
    private String pass;
    private String confirmPass;

    public CompletableFuture<Boolean> Verify(JTextField ConfirmID){
        setConfirmID(ConfirmID);
        return send.Authenticate(confirmID);

    }
    public boolean Check(JPasswordField Password, JPasswordField confirmPassword) {
        setPass(Password,confirmPassword);
        return send.Check(pass,confirmPass);

    }
    public CompletableFuture<Boolean> Change(JPasswordField Password) {
        return send.Change(Password.getText());
    }

    public void setConfirmID(JTextField ConfirmID){
        confirmID = ConfirmID.getText();
    }
    public void setPass(JPasswordField Password , JPasswordField ConfirmPassword){
        pass = Password.getText();
        confirmPass = ConfirmPassword.getText();

    }



}
