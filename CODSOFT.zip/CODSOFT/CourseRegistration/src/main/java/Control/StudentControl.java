package Control;


import Repositories.LoginRepository;

public class StudentControl {
    private LoginRepository collectStudents = new LoginRepository();
    public void prepareStudents() {
        collectStudents.checkUser();
    }
}
