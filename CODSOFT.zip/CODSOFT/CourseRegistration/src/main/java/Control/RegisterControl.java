package Control;

import Model.CourseModel;
import Model.StudentModel;
import Repositories.UpdateCreditsRepo;
import Services.RegisterService;

import java.util.ArrayList;

import static Model.StudentModel.getStudent;

public class RegisterControl {
    private RegisterService registerService = new RegisterService();

    public void Register(String pass, CourseModel c, Boolean drop){
        registerService.Register(pass, c, drop);
    }

    public void RegisterCourses(StudentModel student, ArrayList<CourseModel> list) {
        registerService.RegisterCourses(student,list);
    }
}
