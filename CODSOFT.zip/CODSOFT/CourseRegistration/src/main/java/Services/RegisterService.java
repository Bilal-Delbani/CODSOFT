package Services;

import Model.CourseModel;
import Model.StudentModel;
import Repositories.UpdateCreditsRepo;

import java.util.ArrayList;

import static Model.StudentModel.getStudent;

public class RegisterService {
    private StudentModel student;
    private CourseModel course;
    private UpdateCreditsRepo updateCredits = new UpdateCreditsRepo();
    private UpdateCreditsRepo updateCourses = new UpdateCreditsRepo();
    private UpdateCreditsRepo updateCourseSlots = new UpdateCreditsRepo();

    private static long credits = 0;
    private static long remained_slots;
    public void Register(String pass, CourseModel c, Boolean drop) {
        course = c;
        if(student==null){
            for(StudentModel std: getStudent()){
                if(std.getPassword().equals(pass)){
                    student = std;
                }
            }
        }
        remained_slots = c.getRemained_Slots();
        if(drop){
            credits-=3;
            remained_slots++;
        }
        else{
            credits+=3;
            remained_slots--;
        }
        student.setRegistered_Credits(credits);
        updateCredits.updateCredits(student);
        course.setRemained_Slots(remained_slots);
        updateCourseSlots.updateCourseSlots(course);
    }

    public void RegisterCourses(StudentModel student, ArrayList<CourseModel> list) {
        student.setRegisteredCourses(list);
        updateCourses.UpdateCourses(student);
    }
}
