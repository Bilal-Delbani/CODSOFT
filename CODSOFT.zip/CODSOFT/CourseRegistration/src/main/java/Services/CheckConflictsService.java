package Services;

import Model.CourseModel;
import Model.StudentModel;

import static Model.StudentModel.getStudent;
import static View.CoursesPanel.*;

public class CheckConflictsService {
    public boolean CheckTime(CourseModel c) {
        if(!getCSCset().isEmpty()){
            for(CourseModel course : getCSCset()){
                if(course.getSchedule().equals(c.getSchedule())){
                    return false;
                }
            }
        }
        if(!getARAset().isEmpty()){
            for(CourseModel course : getARAset()){
                if(course.getSchedule().equals(c.getSchedule())){
                    return false;
                }
            }
        }
        if(!getENGset().isEmpty()){
            for(CourseModel course : getENGset()){
                if(course.getSchedule().equals(c.getSchedule())){
                    return false;
                }
            }
        }
        if(!getMTHset().isEmpty()){
            for(CourseModel course : getMTHset()){
                if(course.getSchedule().equals(c.getSchedule())){
                    return false;
                }
            }
        }
        if(!getLACset().isEmpty()){
            for(CourseModel course : getLACset()){
                if(course.getSchedule().equals(c.getSchedule())){
                    return false;
                }
            }
        }
        return true;
    }

    public boolean CheckCredits(CourseModel c, String pass) {
        for(StudentModel s: getStudent()){
            if(s.getPassword().equals(pass)){
                if(s.getRegistered_Credits()<s.getCREDITS()){
                    return true;
                }
            }
        }
        return false;
    }
}
