package Services;
import Repositories.ForgetPassRepository;
import java.util.concurrent.CompletableFuture;
import Model.StudentModel;

import static Model.StudentModel.getStudent;
import static Repositories.ForgetPassRepository.getID;

public class ForgetPassService {
    private ForgetPassRepository forgetPassRepo;
    private String confirmID;
    private String pass;
    private String confirmPass;

    public CompletableFuture<Boolean> Authenticate(String ConfirmID){
        setConfirmID(ConfirmID);
        forgetPassRepo = new ForgetPassRepository();
        return forgetPassRepo.checkConfirmID(confirmID);

    }

    public boolean Check(String Password, String ConfirmPass) {
        setPass(Password, ConfirmPass);
        if(pass.equals("") || confirmPass.equals("") || !pass.equals(confirmPass)){
            return false;
        }
        return true;
    }

    public CompletableFuture<Boolean> Change(String password) {
        for(StudentModel std : getStudent()){
            if(std.getEmail().equals(getID())){
                std.setPassword(password);
            }
        }
        forgetPassRepo = new ForgetPassRepository();
        return forgetPassRepo.changePassword(password);


    }


    public void setConfirmID(String ConfirmID){
        this.confirmID = ConfirmID;
    }
    public void setPass(String Password, String ConfirmPass){
        pass = Password;
        confirmPass = ConfirmPass;
    }



}
