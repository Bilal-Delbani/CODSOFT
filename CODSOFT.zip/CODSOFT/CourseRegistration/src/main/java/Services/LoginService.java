package Services;
import Model.StudentModel;
import static Model.StudentModel.getStudent;

public class LoginService {
    private StudentModel student;
    private String username;
    private String password;
    private String fullName;

    public boolean Authenticate(String Username , String Password){
        setUsername(Username);
        setPassword(Password);
        if(username.equals("") || password.equals("")){
            return false;
        }


        for(StudentModel s: getStudent()){
            if(username.equals(s.getUsername()) && password.equals(s.getPassword())){
                setFullName(s.getFullName());
                return true;
            }
        }

        return false;

    }
    public void setUsername(String Username){
        this.username = Username;
    }
    public void setPassword(String Password){
        this.password = Password;
    }
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String FullName) {
        this.fullName = FullName;
    }


}
