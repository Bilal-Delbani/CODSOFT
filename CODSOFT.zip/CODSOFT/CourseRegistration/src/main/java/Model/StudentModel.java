package Model;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class StudentModel {
    private static HashSet<StudentModel> set = new HashSet<>();
    private String username;
    private String FullName;
    private String email;
    private String studentID;
    private String password;
    private final long CREDITS = 15;
    private long registered_Credits;
    private List<CourseModel> list = new ArrayList<>();

    public StudentModel(){}

    public StudentModel(String username, String FullName, String Email, String StudentID, String password, long registered_Credits, List<CourseModel> list){
        this.username = username;
        this.FullName = FullName;
        this.email = Email;
        this.studentID = StudentID;
        this.password = password;
        this.registered_Credits = registered_Credits;
        this.list = list;
    }


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    public String getFullName() {
        return FullName;
    }

    public static HashSet<StudentModel> getStudent() {
        return set;
    }

    public static void setStudent(StudentModel Student) {
        set.add(Student);
    }

    public long getRegistered_Credits() {
        return registered_Credits;
    }

    public void setRegistered_Credits(long registered_Credits) {
        this.registered_Credits = registered_Credits;
    }
    public long getCREDITS() {
        return CREDITS;
    }

    public List<CourseModel> getRegisteredCourses() {
        return list;
    }

    public void setRegisteredCourses(List<CourseModel> list) {
        this.list = list;
    }
}


