package Model;

import java.util.ArrayList;

public class CourseModel {
    private long ID;
    private String Course;
    private String Title;
    private long Capacity;
    private long Remained_Slots;
    private String Schedule;
    private String Location;
    private long Section;
    private String Instructor;
    private String Description;

    private static ArrayList<CourseModel> CSC = new ArrayList<>();
    private static ArrayList<CourseModel> ARA = new ArrayList<>();
    private static ArrayList<CourseModel> ENG = new ArrayList<>();
    private static ArrayList<CourseModel> MTH = new ArrayList<>();
    private static ArrayList<CourseModel> LAC = new ArrayList<>();

    public CourseModel(long ID, String course, String title, long capacity, long remained_Slots, String schedule, String location, long section, String instructor, String description){
        this.ID = ID;
        Course = course;
        Title = title;
        Capacity = capacity;
        Remained_Slots = remained_Slots;
        Schedule = schedule;
        Location = location;
        Section = section;
        Instructor = instructor;
        Description = description;
    }

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public String getCourse() {
        return Course;
    }

    public void setCourse(String course) {
        Course = course;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getSchedule() {
        return Schedule;
    }

    public void setSchedule(String schedule) {
        Schedule = schedule;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getInstructor() {
        return Instructor;
    }

    public void setInstructor(String instructor) {
        Instructor = instructor;
    }

    public long getCapacity() {
        return Capacity;
    }

    public void setCapacity(int capacity) {
        Capacity = capacity;
    }

    public long getRemained_Slots() {
        return Remained_Slots;
    }

    public void setRemained_Slots(long remained_Slots) {
        Remained_Slots = remained_Slots;
    }

    public long getSection() {
        return Section;
    }

    public void setSection(int section) {
        Section = section;
    }

    public static ArrayList<CourseModel> getCSC() {
        return CSC;
    }

    public static void setCSC(ArrayList<CourseModel> CSC) {
        CourseModel.CSC = CSC;
    }

    public static ArrayList<CourseModel> getARA() {
        return ARA;
    }

    public static void setARA(ArrayList<CourseModel> ARA) {
        CourseModel.ARA = ARA;
    }

    public static ArrayList<CourseModel> getENG() {
        return ENG;
    }

    public static void setENG(ArrayList<CourseModel> ENG) {
        CourseModel.ENG = ENG;
    }

    public static ArrayList<CourseModel> getMTH() {
        return MTH;
    }

    public static void setMTH(ArrayList<CourseModel> MTH) {
        CourseModel.MTH = MTH;
    }

    public static ArrayList<CourseModel> getLAC() {
        return LAC;
    }

    public static void setLAC(ArrayList<CourseModel> LAC) {
        CourseModel.LAC = LAC;
    }


}
