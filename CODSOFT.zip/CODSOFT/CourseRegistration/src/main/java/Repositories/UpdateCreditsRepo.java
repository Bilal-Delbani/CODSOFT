package Repositories;

import BackEnd.ConnectFirebase;
import Model.CourseModel;
import Model.StudentModel;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UpdateCreditsRepo {
    private ConnectFirebase conn;
    private Firestore firestore;
    private CollectionReference contracts;
    private CollectionReference courses;
    private ExecutorService executorService = Executors.newCachedThreadPool();

    public UpdateCreditsRepo(){
        try {
            conn = new ConnectFirebase();
            firestore = conn.getConn();
            contracts = firestore.collection("Contract");
            courses = firestore.collection("Courses");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public CompletableFuture<Void> updateCredits(StudentModel student) {
        return CompletableFuture.runAsync(() -> {
            try {
                DocumentReference document = contracts.document(student.getEmail());
                document.update("CREDITS",student.getRegistered_Credits());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, executorService);

    }

    public CompletableFuture<Void> updateCourseSlots(CourseModel course) {
        return CompletableFuture.runAsync(() -> {
            try {
                DocumentReference document = courses.document(String.valueOf(course.getID()));
                document.update("REMAINED_SLOTS",course.getRemained_Slots());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, executorService);

    }

    public CompletableFuture<Void> UpdateCourses(StudentModel student) {
        return CompletableFuture.runAsync(() -> {
            try {
                DocumentReference document = contracts.document(student.getEmail());
                document.update("REGISTERED_COURSES",student.getRegisteredCourses());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, executorService);

    }
}
