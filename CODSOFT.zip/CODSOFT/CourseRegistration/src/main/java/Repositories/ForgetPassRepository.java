package Repositories;

import BackEnd.ConnectFirebase;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ForgetPassRepository {
    private ConnectFirebase conn;
    private Firestore firestore;
    private CollectionReference contracts;
    private ExecutorService executorService = Executors.newCachedThreadPool();
    private static String ID;

    public ForgetPassRepository(){
        try {
            conn = new ConnectFirebase();
            firestore = conn.getConn();
            contracts = firestore.collection("Contract");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public CompletableFuture<Boolean> checkConfirmID(String enteredConfirmID) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                ApiFuture<QuerySnapshot> querySnapshot = contracts.get();
                List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();
                for (QueryDocumentSnapshot document : documents) {
                    String name = document.getString("FULL_NAME").split(" ")[0];
                    String stdID = document.getString("STUDENT_ID");
                    String confirmationID = name+stdID;

                    if (enteredConfirmID.equals(confirmationID)) {
                        ID = document.getString("EMAIL");
                        return true;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            ID="";
            return false;
        }, executorService);
    }

    public CompletableFuture<Boolean> changePassword(String pass) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                DocumentReference document = contracts.document(ID);
                document.update("PASSWORD",pass);
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }, executorService);

    }
    public static String getID() {
        return ID;
    }

}
