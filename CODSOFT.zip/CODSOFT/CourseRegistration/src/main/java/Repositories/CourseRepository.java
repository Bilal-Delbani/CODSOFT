package Repositories;

import BackEnd.ConnectFirebase;
import Model.CourseModel;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static Model.CourseModel.*;

public class CourseRepository {
    private ConnectFirebase conn;
    private Firestore firestore;
    private CollectionReference courses;
    private ExecutorService executorService = Executors.newCachedThreadPool();

    public CourseRepository() {
        try {
            conn = new ConnectFirebase();
            firestore = conn.getConn();
            courses = firestore.collection("Courses");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public CompletableFuture<Void> Prepare() {
        getLAC().clear();
        getENG().clear();
        getMTH().clear();
        getARA().clear();
        getCSC().clear();
        return CompletableFuture.runAsync(() -> {
            try {
                ApiFuture<QuerySnapshot> querySnapshot = courses.get();
                List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();
                for (QueryDocumentSnapshot document : documents) {
                    long ID = document.getLong("ID");
                    String Course = document.getString("COURSE");
                    String Title = document.getString("TITLE");
                    long Capacity = document.getLong("CAPACITY");
                    long Remained_Slots = document.getLong("REMAINED_SLOTS");
                    String Instructor = document.getString("INSTRUCTOR");
                    String Schedule = document.getString("SCHEDULE");
                    String Location = document.getString("LOCATION");
                    long Section =  document.getLong("SECTION");
                    String Description = document.getString("DESCRIPTION");
                    CourseModel course = new CourseModel(ID,Course, Title, Capacity, Remained_Slots, Schedule, Location, Section, Instructor, Description);

                    String group = Course.substring(0,3);
                    switch (group){
                        case "CSC":
                            getCSC().add(course);
                            break;
                        case "ARA":
                            getARA().add(course);
                            break;
                        case "ENG":
                            getENG().add(course);
                            break;
                        case "MTH":
                            getMTH().add(course);
                            break;
                        default:
                            getLAC().add(course);
                            break;
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, executorService);
    }
}
