package Repositories;

import BackEnd.ConnectFirebase;
import Model.CourseModel;
import Model.StudentModel;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static Model.StudentModel.getStudent;
import static Model.StudentModel.setStudent;

public class LoginRepository {
    private ConnectFirebase conn;
    private Firestore firestore;
    private CollectionReference contracts;

    private ExecutorService executorService = Executors.newCachedThreadPool();

    public LoginRepository() {
        try {
            conn = new ConnectFirebase();
            firestore = conn.getConn();
            contracts = firestore.collection("Contract");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public CompletableFuture<Void> checkUser() {
        getStudent().clear();
        return CompletableFuture.runAsync(() -> {
            try {
                ApiFuture<QuerySnapshot> querySnapshot = contracts.get();
                List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();
                for (QueryDocumentSnapshot document : documents) {
                    String username = document.getString("EMAIL").split("@")[0];
                    String name = document.getString("FULL_NAME");
                    String email = document.getString("EMAIL");
                    String studentID = document.getString("STUDENT_ID");
                    String password = document.getString("PASSWORD");
                    long credits = document.getLong("CREDITS");
                    List<CourseModel> list = (List<CourseModel>) document.get("REGISTERED_COURSES");

                    StudentModel std = new StudentModel(username, name,email, studentID, password, credits, list);
                    setStudent(std);
                }

            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }, executorService);
    }
}
